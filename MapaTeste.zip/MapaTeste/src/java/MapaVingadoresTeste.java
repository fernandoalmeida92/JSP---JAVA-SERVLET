/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author f_sil
 */
public class MapaVingadoresTeste extends HttpServlet {
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        int valor1, valor2, valor3, valor4,valor5, valor6, valor7, valor8;
        int resultado;
        String personagem;
        
        try{
            valor1 =Integer.valueOf(request.getParameter("questao1"));
            valor2 =Integer.valueOf(request.getParameter("questao2"));
            valor3 =Integer.valueOf(request.getParameter("questao3"));
            valor4 =Integer.valueOf(request.getParameter("questao4"));
            valor5 =Integer.valueOf(request.getParameter("questao5"));
            valor6 =Integer.valueOf(request.getParameter("questao6"));
            valor7 =Integer.valueOf(request.getParameter("questao7"));
            valor8 =Integer.valueOf(request.getParameter("questao8"));
            resultado = valor1 + valor2 + valor3 + valor4 + valor5 + valor6 + valor7 + valor8;

            if(resultado < 11)personagem = "Homem-Aranha";
            else if(resultado < 14)personagem = "Doutor Estranho";
            else if(resultado < 17)personagem = "Feiticeira Escarlate";
            else if(resultado < 20)personagem = "Thor";
            else if(resultado < 23)personagem = "Hulk";
            else if(resultado < 26)personagem = "Viúva Negra";
            else if(resultado < 29)personagem = "Homem de Ferro";
            else personagem = "Capitão América";
            
        }catch(Exception e){
            personagem = "<style>p{color: red;}</style><p>ERROR! campo em branco. <br> Retorne na Página anterior!<p>";
        }
        
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>MapaVingadoresTeste</title>");
            out.println("<style>");
            out.println("a{text-decoration:none;}");
            out.println("body{background-image: url('vingadores6.jpg');"
                    + "background-repeat: no-repeat;"
                    + "font-size: 30px;"
                    + "font-family: calibri, san-serif;"
                    + "color: black;}");
            out.println("");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1><center>Você é: "+ personagem + "</center></h1>");
            out.println("<button type='submit'><a href='./endDadosMapa.jsp'><< VOLTAR</a></button>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
